
You've intercepted a suspicious image file. Something seems off about it, but you can't quite put your finger on it. Can you uncover what's hidden within?


Autor: 0xNay33m

Flag Format: BICS77{...}

