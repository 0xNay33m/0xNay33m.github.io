Prototype secure channel for internal testing.
Protocol may change.
Passwords are alphanumeric only (a–z, 0–9).


Author: 0xNay33m
Flag Format: BICS77{s0me_t3xt}
