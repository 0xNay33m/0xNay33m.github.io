# Fragmented Trust

A fintech startup designed its own "secure" crypto wallet.
They split encryption keys for "extra security"...
But trust was fragmented — and so was their crypto.

Author: 0xNay33m
Flag Format: BICS77{s0me_t3xt}
